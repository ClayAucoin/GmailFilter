"""
python3 '/mnt/c/_lib/data/_scripts_/py/_projects/GmailFilter/gmail_auth_test.py'
"""

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import os
import pickle

# Step 1: Set the Gmail access scope
SCOPES = ['https://mail.google.com/']

# Step 2: Get Gmail service with OAuth
def get_gmail_service():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    else:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=8080)  # This opens your browser to sign in
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return build('gmail', 'v1', credentials=creds)

# Step 3: Test the connection by listing labels
if __name__ == '__main__':
    service = get_gmail_service()
    results = service.users().labels().list(userId='me').execute()
    labels = results.get('labels', [])
    print("✔ Connected to Gmail API — Your Labels:")
    for label in labels:
        print(f"- {label['name']}")
