
# python3 '/mnt/c/_lib/data/_scripts_/py/_projects/GmailFilter/filter_from_csv.py'

# python3 C:\_lib\data\_scripts_\py\_projects\GmailFilter/filter_from_csv.py



import csv
import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# === CONFIG ===
SCOPES = ['https://www.googleapis.com/auth/gmail.settings.basic']
CSV_FILE = 'blocklist.csv'
CHUNK_SIZE = 1400  # Safe limit for Gmail filter query length


# === AUTH ===
def get_gmail_service():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    else:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=8888)
        print("Granted Scopes:", creds.scopes)
        # creds = flow.run_console()

        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return build('gmail', 'v1', credentials=creds)


# === LOAD EMAILS ===
def load_blocklist_from_csv(file_path):
    with open(file_path, newline='') as f:
        reader = csv.reader(f)
        emails = [row[0].strip() for row in reader if row]
    return list(set(emails))  # Remove duplicates


# === CREATE FILTER ===
def create_gmail_filter(service, query):
    filter_config = {
        "criteria": {
            "from": query
        },
        "action": {
            "removeLabelIds": ["INBOX"],
            "addLabelIds": ["TRASH"]
        }
    }
    result = service.users().settings().filters().create(userId='me', body=filter_config).execute()
    print(f"✔ Created filter ID: {result.get('id')}")


def delete_all_gmail_filters(service):
    try:
        filters = service.users().settings().filters().list(userId='me').execute()
        existing_filters = filters.get('filter', [])

        if not existing_filters:
            print("📭 No existing filters to delete.")
            return

        for f in existing_filters:
            service.users().settings().filters().delete(userId='me', id=f['id']).execute()
            print(f"🗑 Deleted filter ID: {f['id']}")

        print(f"✅ Deleted {len(existing_filters)} existing filter(s).")

    except Exception as e:
        print("❌ Failed to delete filters:", e)


def delete_matching_filters(service, blocklist_emails):
    try:
        filters = service.users().settings().filters().list(userId='me').execute()
        existing_filters = filters.get('filter', [])
        deleted_count = 0

        for f in existing_filters:
            criteria = f.get('criteria', {})
            from_field = criteria.get('from', '')
            query_field = criteria.get('query', '')

            # Check if any blocklist email appears in either 'from' or 'query'
            if any(email in from_field or email in query_field for email in blocklist_emails):
                service.users().settings().filters().delete(userId='me', id=f['id']).execute()
                print(f"🗑 Deleted filter ID: {f['id']}")
                deleted_count += 1

        if deleted_count:
            print(f"✅ Deleted {deleted_count} matching filter(s).")
        else:
            print("📭 No matching filters found to delete.")

    except Exception as e:
        print("❌ Failed to delete filters:", e)



# === MAIN ===
def main():
    service = get_gmail_service()
    emails = load_blocklist_from_csv(CSV_FILE)

    print(f"Loaded {len(emails)} emails from blocklist.")

    # Only delete filters that match the blocklist
    delete_matching_filters(service, emails)

    current_chunk = []
    current_length = 0

    for email in emails:
        filter_piece = f"{email}"
        if current_length + len(filter_piece) + 4 > CHUNK_SIZE:
            query = " OR ".join(current_chunk)
            create_gmail_filter(service, query)
            current_chunk = []
            current_length = 0
        current_chunk.append(filter_piece)
        current_length += len(filter_piece) + 4

    if current_chunk:
        query = " OR ".join(current_chunk)
        create_gmail_filter(service, query)

    print("✅ All filters uploaded successfully.")



if __name__ == '__main__':
    main()
